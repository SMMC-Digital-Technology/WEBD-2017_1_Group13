var myTax;

function calculateTax() {
    myTax = document.getElementById("inputTax").value;
    if (myTax < 16000) {
        alert("No tax for you!");
        document.getElementById("outputTax").value = myTax * 2;
    }

}