var myTax;

function calculateTax() {
    myTax = document.getElementById("inputTax").value;
    if (myTax < 16000) {
        document.getElementById("outputTax").value = 0;
    } else if (myTax < 52500) {
        myTax = myTax - 16000;  //How much over 16000 did they earn
        myTax = myTax * 0.1;    //Get 10% of the remainder
        document.getElementById("outputTax").value = myTax;
    } else if (myTax < 113000) {
        myTax = myTax - 52500;  //How much over 52500 did they earn
        myTax = myTax * 0.16;    //Get 16% of the remainder
        myTax = myTax + 3650;   //Add some extra tax
        document.getElementById("outputTax").value = myTax;
    }    else if (myTax < 184500) {
        myTax = myTax - 113000;  //How much over 16000 did they earn
        myTax = myTax * 0.24;    //Get 24% of the remainder
        myTax = myTax + 13330;   //Get some extra tax
        document.getElementById("outputTax").value = myTax;
    }    else {
        myTax = myTax - 184500;  //How much over 16000 did they earn
        myTax = myTax * 0.36;    //Get 36% of the remainder
        myTax = myTax + 30490;   //Get some extra tax
    }

}